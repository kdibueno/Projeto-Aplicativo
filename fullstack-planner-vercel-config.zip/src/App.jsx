import FullstackPlanApp from './FullstackPlanApp'
import React, { useState, useEffect } from "react";



function App() {
  return <FullstackPlanApp />
}

export default App