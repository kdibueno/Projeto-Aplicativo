import FullstackPlanApp from './FullstackPlanApp'

function App() {
  return <FullstackPlanApp />
}

export default App